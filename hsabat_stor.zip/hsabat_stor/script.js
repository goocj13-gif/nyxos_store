// بيانات الدخول السرية للوحة التحكم
const SECRET_ADMIN_USER = "nexus_admin_2026";
const SECRET_ADMIN_PASS = "secure_pass_9988";

let selectedProduct = "";
let selectedPrice = "";

document.addEventListener("DOMContentLoaded", () => {
    loadSettings();
    loadOrders();
    
    const adminBtn = document.getElementById("adminLoginBtn");
    if(adminBtn) {
        adminBtn.addEventListener("click", () => {
            document.getElementById("adminLoginModal").style.display = "flex";
        });
    }
});

function closeModal() {
    const modal = document.getElementById("orderModal");
    if(modal) modal.style.display = "none";
}

function closeAdminLogin() {
    const modal = document.getElementById("adminLoginModal");
    if(modal) modal.style.display = "none";
}

function orderItem(productName, price) {
    selectedProduct = productName;
    selectedPrice = price;
    const txt = document.getElementById("selectedItemText");
    if(txt) txt.innerText = `المنتج المختار: ${productName} (${price})`;
    const modal = document.getElementById("orderModal");
    if(modal) modal.style.display = "flex";
}

// إرسال الطلب وحفظه في الذاكرة لتصل إلى لوحة التحكم من أي صفحة
function submitOrder(e) {
    e.preventDefault();
    const name = document.getElementById("clientName").value;
    const contact = document.getElementById("clientContact").value;
    const notes = document.getElementById("clientNotes").value;

    const newOrder = {
        id: Date.now().toString().slice(-4),
        name: name,
        contact: contact,
        product: `${selectedProduct} - ${selectedPrice}`,
        notes: notes || "لا توجد ملاحظات",
        date: new Date().toLocaleString()
    };

    let orders = JSON.parse(localStorage.getItem("store_orders")) || [];
    orders.unshift(newOrder);
    localStorage.setItem("store_orders", JSON.stringify(orders));

    alert("تم إرسال طلبك بنجاح إلى الإدارة وسيتم التواصل معك قريباً!");
    document.getElementById("checkoutForm").reset();
    closeModal();
    loadOrders();
}

function adminLogin(e) {
    e.preventDefault();
    const user = document.getElementById("adminUser").value;
    const pass = document.getElementById("adminPass").value;

    if (user === SECRET_ADMIN_USER && pass === SECRET_ADMIN_PASS) {
        document.getElementById("adminLoginModal").style.display = "none";
        document.getElementById("adminDashboard").style.display = "block";
        loadOrders();
    } else {
        alert("خطأ في اسم المستخدم أو كلمة المرور السرية!");
    }
}

function adminLogout() {
    document.getElementById("adminDashboard").style.display = "none";
}

function switchAdminTab(tabId) {
    document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));
    document.querySelectorAll(".admin-tab-content").forEach(content => content.classList.remove("active"));
    event.currentTarget.classList.add("active");
    document.getElementById(tabId).classList.add("active");
}

function loadOrders() {
    let orders = JSON.parse(localStorage.getItem("store_orders")) || [];
    const countEl = document.getElementById("ordersCount");
    if(countEl) countEl.innerText = orders.length;
    
    const tbody = document.getElementById("ordersTableBody");
    if(!tbody) return;

    if (orders.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: #94a3b8;">لا توجد طلبات جديدة حالياً.</td></tr>`;
        return;
    }

    tbody.innerHTML = "";
    orders.forEach((order, index) => {
        tbody.innerHTML += `
            <tr>
                <td>#${order.id}</td>
                <td>${order.name}</td>
                <td>${order.contact}</td>
                <td><b>${order.product}</b></td>
                <td>${order.notes}</td>
                <td>${order.date}</td>
                <td><button class="btn-danger" style="padding: 3px 8px; font-size: 0.8rem;" onclick="deleteOrder(${index})">حذف</button></td>
            </tr>
        `;
    });
}

function deleteOrder(index) {
    let orders = JSON.parse(localStorage.getItem("store_orders")) || [];
    orders.splice(index, 1);
    localStorage.setItem("store_orders", JSON.stringify(orders));
    loadOrders();
}

function saveCustomizations(e) {
    e.preventDefault();
    const settings = {
        brandName: document.getElementById("settingBrandName").value,
        heroTitle: document.getElementById("settingHeroTitle").value,
        primaryColor: document.getElementById("settingPrimaryColor").value
    };
    localStorage.setItem("store_settings", JSON.stringify(settings));
    applySettings(settings);
    alert("تم حفظ التعديلات بنجاح!");
}

function loadSettings() {
    let savedSettings = localStorage.getItem("store_settings");
    if (savedSettings) {
        let settings = JSON.parse(savedSettings);
        applySettings(settings);
    }
}

function applySettings(settings) {
    const brandEls = document.querySelectorAll("#brandName, #footerBrand");
    brandEls.forEach(el => { if(el) el.innerText = settings.brandName; });
    
    const heroTitle = document.getElementById("heroTitle");
    if(heroTitle) heroTitle.innerText = settings.heroTitle;
    
    if(settings.primaryColor) {
        document.documentElement.style.setProperty('--primary-color', settings.primaryColor);
    }
}
